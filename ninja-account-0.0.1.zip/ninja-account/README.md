# ninja-account
Ninja Account browser extension

Ninja Otter : Anonymous Accounts Made Easy

Anonymous accounts with
No Email
No Password
No Firstname, Lastname, poneyname
No whateverrrrr
... just plain ninja.

Let me Otter my way in your site.

Otter : Hodor
Otter : Authors


TODO :
- Better passwords
- Better User Names
- Better feedback messages ( Generating, you can now continue, ...)
- There should be 2 different buttons "Use this ninja" and "create this ninja" instead of just "do ninja login" (or not?)
